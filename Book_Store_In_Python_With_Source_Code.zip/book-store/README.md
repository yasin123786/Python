# book-store
A small python GUI application that will store book information
