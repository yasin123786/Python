conf = {
    'words_file': './words.txt',
    'max_tries': 8
}